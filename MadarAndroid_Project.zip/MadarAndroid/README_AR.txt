MADAR - مشروع أندرويد لتغليف لعبة HTML

المشروع يضع ملف اللعبة داخل WebView ليعمل كتطبيق أندرويد.

طريقة إنشاء APK:
1) نزّل Android Studio وثبّته.
2) فك ضغط MadarAndroid.zip.
3) افتح Android Studio ثم اختر Open وحدد مجلد MadarAndroid.
4) انتظر Gradle Sync، وثبّت أي SDK يطلبه Android Studio.
5) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
6) بعد اكتمال البناء اضغط Locate لعرض ملف APK.

ملاحظات:
- هذا مشروع مصدر وليس ملف APK جاهزًا.
- يلزم Android Studio/Android SDK واتصال إنترنت أول مرة لتنزيل أدوات البناء.
- اللعبة تستخدم localStorage لحفظ التقدم، وتم تفعيل DOM storage في WebView.
- خط Orbitron في ملف HTML قد يحتاج اتصال إنترنت لتحميله؛ توجد خطوط نظام بديلة في CSS.
